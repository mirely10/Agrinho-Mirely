let player;
let objetos = [];
let perguntasRespondidas = 0;
let perguntaAtual = null;
let estado = "jogo"; // ou "pergunta"
let pontuacao = 0;

function setup() {
  createCanvas(600, 400);
  player = { x: 50, y: 200, size: 30 };

  objetos.push({
    x: 150,
    y: 200,
    pergunta: "O que se encontra mais no campo?",
    opcoes: ["Trânsito", "Plantação", "Shopping"],
    correta: 1
  });

  objetos.push({
    x: 450,
    y: 200,
    pergunta: "Qual é comum na cidade?",
    opcoes: ["Trator", "Galinha", "Prédio"],
    correta: 2
  });
}

function draw() {
  background(220);

  // Metade campo / cidade
  fill(180, 250, 180);
  rect(0, 0, width / 2, height);
  fill(180, 180, 250);
  rect(width / 2, 0, width / 2, height);

  fill(0);
  text("CAMPO", width / 4, 30);
  text("CIDADE", (3 * width) / 4, 30);

  // Objetos
  for (let o of objetos) {
    fill(255, 200, 0);
    ellipse(o.x, o.y, 30, 30);
  }

  // Player
  fill(0);
  ellipse(player.x, player.y, player.size);

  if (estado === "pergunta") {
    mostrarPergunta(perguntaAtual);
  }

  if (objetos.length === 0 && estado !== "pergunta") {
    fill(0);
    textSize(24);
    text("Missão completa!", width / 2, height / 2);
  }
}

function keyPressed() {
  if (estado !== "jogo") return;

  if (keyCode === LEFT_ARROW) player.x -= 5;
  if (keyCode === RIGHT_ARROW) player.x += 5;
  if (keyCode === UP_ARROW) player.y -= 5;
  if (keyCode === DOWN_ARROW) player.y += 5;

  // Colisão
  for (let i = objetos.length - 1; i >= 0; i--) {
    let o = objetos[i];
    let d = dist(player.x, player.y, o.x, o.y);
    if (d < 25) {
      estado = "pergunta";
      perguntaAtual = o;
      objetos.splice(i, 1);
      break;
    }
  }
}

function mostrarPergunta(p) {
  fill(255);
  rect(50, 100, width - 100, 200);
  fill(0);
  textSize(18);
  text(p.pergunta, width / 2, 140);
  for (let i = 0; i < p.opcoes.length; i++) {
    let y = 180 + i * 30;
    text(`${i + 1}. ${p.opcoes[i]}`, width / 2, y);
  }
}

function keyTyped() {
  if (estado === "pergunta") {
    let index = parseInt(key) - 1;
    if (index === perguntaAtual.correta) {
      pontuacao++;
      alert("Correto!");
    } else {
      alert("Errado!");
    }
    estado = "jogo";
  }
}